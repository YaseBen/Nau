import java.util.Random;

public class Objectes {
    Random Rand = new Random();
    
    int objecte = Rand.nextInt(0,6);
    String descripcio;

    public Objectes(){
        switch(objecte){
            case 0:

                descripcio="La llanterna serveix per il·luminar les sales oscures.";

            break;

            case 1:

            descripcio="El traje espacial serveix per poder sortir a la sala de motors";

            break;

            case 2:

            descripcio="La caixa d'eines serveix per arreglar els motors";

            break;

            case 3:

            descripcio="El calaix requereix una clau";

            break;

            case 4:

            descripcio="La tarjeta d'en Bond es util per obrir portes";

            break;

            case 5:

            descripcio="Tarjeta d'un tripulant serveix per obrir portes";

            break;

            case 6:

            descripcio="El donut es fa servir per entretenir el Guzman";

            break;
    
            default:
            break;
            
        }
    }

}