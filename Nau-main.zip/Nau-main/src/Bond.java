public class Bond extends Personatges {

}
