import java.util.Random;

public class iHall{
    static Random rand = new Random();
    
    public static void llanterna() {
        int resposta = rand.nextInt(2); // Cambiar a 2 para obtener 0 o 1
        if (resposta == 1) {
            System.out.println("BoNd, La LlEnTeRnA eStÀ a " + MapaHabitaciones.mapa.get(Habitaciones.llanterna).getDescripcio() + " CoM sEmPrE");
        } else {
            int samba = rand.nextInt(9);
            switch (samba) {
                case 0:
                    System.out.println("EN LA TEVA ZONA RECTAL!");
                    break;
                case 1:
                    System.out.println("S'ha caigut al lavabo quantic.");
                    break;
                case 2:
                    System.out.println("Tenia gana i me l'he esmorzat.");
                    break;
                case 3:
                    System.out.println("Ens la vam deixar a la Terra.");
                    break;
                case 4:
                    System.out.println("A mi que cony em preguntes.");
                    break;
                case 5:
                    System.out.println("A que vaig jo i la trobo...");
                    break;
                case 6:
                    System.out.println("Tu sabràs on deixes les teves coses capsigrany.");
                    break;
                case 7:
                    System.out.println("Has mirat a sota la bandeja.");
                    break;
                case 8:
                    System.out.println("es oh oN.");
                    break;
            }

        }
    }
    public static void falseMoure() {
        System.out.println("No penso obrir la porta, no em ve de gust...");
    }
}
/*
import java.util.ArrayList;
import java.util.Random;

public class iHall {
    private Random rand = new Random();
    private ArrayList<Habitaciones> mapa;

    public iHall(MapaHabitaciones mapaHabitaciones) {
        this.mapa = mapaHabitaciones.getMapa(); // Obtener el mapa de habitaciones
    }

    public void llanterna() {
        int resposta = rand.nextInt(2); // Cambiar a 2 para obtener 0 o 1
        if (resposta == 1) {
            System.out.println("BoNd, La LlEnTeRnA eStÀ a " + mapa.get(getLlanterna()).getDescripcio() + " CoM sEmPrE");
        } else {
            System.out.println("La linterna no se encuentra.");
        }
    }

    public int getLlanterna() {
        // Aquí deberías devolver el índice de la linterna o algo similar
        return 0; 
    }
}
*/