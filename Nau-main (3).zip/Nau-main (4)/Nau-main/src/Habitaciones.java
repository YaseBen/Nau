import java.util.Random;

public class Habitaciones {
    private int nombre;
    private int dreta;
    private int esquerra;
    private int amunt;
    private int abaix;
    private String descripcio;
    private boolean eina;
    private boolean donuts;
    private boolean vestitEspacial;
    private boolean tarjeta;
    private boolean company;
    static int llanterna;
    private Random rand = new Random();

    // Constructor que recibe el número de habitación
    public Habitaciones(int nombre) {
        this.nombre = nombre; // Inicializa el nombre
        switch (nombre) {
            case 1:
                this.dreta = -1;
                this.esquerra = 7;
                this.amunt = 2;
                this.abaix = -1;
                this.descripcio = "Dormitori";
                this.company = true;
                this.donuts = false;
                break;
            case 2:
                this.dreta = -1;
                this.esquerra = 3;
                this.amunt = -1;
                this.abaix = 1;
                this.descripcio = "Banys";
                this.donuts = false;
                break;
            case 3:
                this.dreta = 2;
                this.esquerra = 5;
                this.amunt = 4;
                this.abaix = 9;
                this.descripcio = "Oficines";
                this.tarjeta = true;
                this.donuts = false;
                break;
            case 4:
                this.dreta = -1;
                this.esquerra = -1;
                this.amunt = -1;
                this.abaix = 3;
                this.descripcio = "Taller";
                this.eina = true;
                this.donuts = false;
                break;
            case 5:
                this.dreta = 3;
                this.esquerra = -1;
                this.amunt = -1;
                this.abaix = 6;
                this.descripcio = "Vestuari";
                this.vestitEspacial = true;
                this.donuts = false;
                break;
            case 6:
                this.dreta = 7;
                this.esquerra = -1;
                this.amunt = 5;
                this.abaix = -1;
                this.descripcio = "Cuina";
                this.donuts = true;
                break;
            case 7:
                this.dreta = 1;
                this.esquerra = 6;
                this.amunt = -1;
                this.abaix = 8;
                this.descripcio = "Menjador";
                this.donuts = false;
                break;
            case 8:
                this.dreta = -1;
                this.esquerra = -1;
                this.amunt = 7;
                this.abaix = 10;
                this.descripcio = "Sala sortida exterior";
                this.donuts = false;
                break;
            case 9:
                this.dreta = -1;
                this.esquerra = -1;
                this.amunt = 3;
                this.abaix = -1;
                this.descripcio = "Comandament";
                this.donuts = false;
                break;
            case 10:
                this.dreta = -1;
                this.esquerra = -1;
                this.amunt = 8;
                this.abaix = -1;
                this.descripcio = "Propulsors";
                this.donuts = false;
                break;
        }
        llanterna = rand.nextInt(10) + 1;
    }

    public int getNombre() {
        return nombre;
    }

    public int getDreta() {
        return dreta;
    }

    public int getEsquerra() {
        return esquerra;
    }

    public int getAmunt() {
        return amunt;
    }

    public int getAbaix() {
        return abaix;
    }

    public String getDescripcio() {
        return descripcio;
    }

    public int getLlanterna() {
        return llanterna;
    }

    public boolean getEina() {
        return eina;
    }

    public boolean getDonuts() {
        return donuts;
    }

    public boolean getVestitEspacial() {
        return vestitEspacial;
    }

    public boolean getTarjeta() {
        return tarjeta;
    }

    public boolean getCompany() {
        return company;
    }
}
