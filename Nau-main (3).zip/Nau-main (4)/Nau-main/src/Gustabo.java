import java.util.Random;

public class Gustabo{
    
    Random rand = new Random();
    int posicioActual = 8;
    
    public void Movimiento(int torn){
        
        int novaPosicio=0;
        
        if (torn%2==0) {
        
            while (posicioActual == novaPosicio) {
                
                int direccio = rand.nextInt(1,4);
                switch (direccio) {
                    case 1:
                        MapaHabitaciones.moureAmunt();
                        break;
                    case 2:
                        MapaHabitaciones.moureAbaix();
                        break;
                    case 3:
                        MapaHabitaciones.moureEsquerra();
                        break;
                    case 4:
                        MapaHabitaciones.moureDreta();
                        break;
                }

            }
            posicioActual = novaPosicio;

        }    
    }

    public void Comer(){      
          
    }
}
