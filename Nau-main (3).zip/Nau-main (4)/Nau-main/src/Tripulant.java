import java.util.Random;
public class Tripulant{
        public void Movimiento(int torn){
        Random rand = new Random();
        boolean despertar = Bond.Despertar();
        if (despertar==true) {
        int posicioActual = 1;
        int novaPosicio=0;
            while (posicioActual == novaPosicio) {
                
                int direccio = rand.nextInt(1,4);
                switch (direccio) {
                    case 1:
                        MapaHabitaciones.moureAmunt();
                        break;
                    case 2:
                        MapaHabitaciones.moureAbaix();
                        break;
                    case 3:
                        MapaHabitaciones.moureEsquerra();
                        break;
                    case 4:
                        MapaHabitaciones.moureDreta();
                        break;
                }
            }
            posicioActual = novaPosicio;
        }    
    }
}
