
/*
public class Objectes {
    private static final String[] DESCRIPCIONS = {
        "La llanterna serveix per il·luminar les sales oscures.",
        "El traje espacial serveix per poder sortir a la sala de motors.",
        "La caixa d'eines serveix per arreglar els motors.",
        "El calaix requereix una clau.",
        "La tarjeta d'en Bond és útil per obrir portes.",
        "Tarjeta d'un tripulant serveix per obrir portes.",
        "El donut es fa servir per entretenir el Guzman."
    };
    
    private Random rand = new Random();
    private Set<Integer> objectesUtilitzats = new HashSet<>(); // Set per rastrejar objectes ja utilitzats
    private String descripcio;

    public Objectes() {
        int objecte;
        
        // Generar un objecte que no hagi estat utilitzat
        do {
            objecte = rand.nextInt(DESCRIPCIONS.length); // Generar un index aleatori
        } while (objectesUtilitzats.contains(objecte)); // Comprovar si ja s'ha utilitzat

        objectesUtilitzats.add(objecte); // Afegir el index a la llista d'objectes utilitzats
        descripcio = DESCRIPCIONS[objecte]; // Assignar la descripció basada en l'índex
    }

    public String getDescripcio() {
        return descripcio; // Mètode per obtenir la descripció
    }

    // Opcional: mètode per comprovar si tots els objectes s'han utilitzat
    public boolean totsObjectesUtilitzats() {
        return objectesUtilitzats.size() == DESCRIPCIONS.length;
    }
}*/
import java.util.Random;

public class Objectes {
    private String descripcio; // Variable para la descripción del objeto
    private int objecte; // Variable para almacenar el tipo de objeto

    // Constructor
    public Objectes() {
        Random rand = new Random();
        this.objecte = rand.nextInt(7); 

        switch (objecte) {
            case 0:
                descripcio = "La llanterna serveix per il·luminar les sales oscures.";
                break;
            case 1:
                descripcio = "El traje espacial serveix per poder sortir a la sala de motors.";
                break;
            case 2:
                descripcio = "La caixa d'eines serveix per arreglar els motors.";
                break;
            case 3:
                descripcio = "El calaix requereix una clau.";
                break;
            case 4:
                descripcio = "La tarjeta d'en Bond es util per obrir portes.";
                break;
            case 5:
                descripcio = "Tarjeta d'un tripulant serveix per obrir portes.";
                break;
            case 6:
                descripcio = "El donut es fa servir per entretenir el Guzman.";
                break;
            default:
                descripcio = "Objecte desconegut.";
                break;
        }
    }

    // Método para obtener la descripción del objeto
    public String getDescripcio() {
        return descripcio;
    }
}
