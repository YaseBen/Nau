import java.util.ArrayList;

public class MapaHabitaciones {
    static int posicioActual;
    static ArrayList<Habitaciones> mapa;

    public MapaHabitaciones() {
        mapa = new ArrayList<>(10);

        // Inicializamos las habitaciones
        for (int i = 1; i <= 10; i++) {
            mapa.add(new Habitaciones(i));
        }
        // Inicializamos la posición actual (habitacion 1)
        posicioActual = 0;
    }
    
    public ArrayList<Habitaciones> getMapa() {
        return mapa; // Método público para acceder al mapa
    }

    public static void moureDreta() {
        int novaPosicio = mapa.get(posicioActual).getDreta();
        if (novaPosicio != -1) {
            posicioActual = novaPosicio - 1;
            mostrarPosicioActual();
        } else {
            System.out.println("No pots moure't més a la dreta. Perds un torn xocant contra la paret.");
        }
    }

    public static void moureEsquerra() {
        int novaPosicio = mapa.get(posicioActual).getEsquerra();
        if (novaPosicio != -1) {
            posicioActual = novaPosicio - 1;
            mostrarPosicioActual();
        } else {
            System.out.println("No pots moure't més a l'esquerra. Perds un torn xocant contra la paret.");
        }
    }

    public static void moureAmunt() {
        int novaPosicio = mapa.get(posicioActual).getAmunt();
        if (novaPosicio != -1) {
            posicioActual = novaPosicio - 1;
            mostrarPosicioActual();
        } else {
            System.out.println("No pots moure't més amunt. Perds un torn xocant contra la paret.");
        }
    }

    public static void moureAbaix() {
        int novaPosicio = mapa.get(posicioActual).getAbaix();
        if (novaPosicio != -1) {
            posicioActual = novaPosicio - 1;
            mostrarPosicioActual();
        } else {
            System.out.println("No pots moure't més avall. Perds un torn xocant contra la paret.");
        }
    }

    public static void mostrarPosicioActual() {
        System.out.println("Estàs a: " + mapa.get(posicioActual).getDescripcio());
    }
}
