import java.util.ArrayList;
import java.util.Random;

public class Bond {
    Random rand = new Random();
    ArrayList<Objectes> objectes = new ArrayList<>();// Lista de objetos que Bond puede utilizar
    // Inicializamos la lista de objetosº

    public void Movimiento() {
        MapaHabitaciones.mostrarPosicioActual();
        System.out.println("A quina direcció et vols moure? (w = amunt, s = abaix, a = esquerra, d = dreta)");
        int direccio = rand.nextInt();

        switch (direccio) {
            case 0:
                MapaHabitaciones.moureAmunt();
                break;
            case 1:
                MapaHabitaciones.moureAbaix();
                break;
            case 2:
                MapaHabitaciones.moureEsquerra();
                break;
            case 3:
                MapaHabitaciones.moureDreta();
                break;
        }
    }

    public void utilitzarObjecte() {
        if (objectes.isEmpty()) {
            System.out.println("Bond no tiene objetos para utilizar.");
            return;
        }

        // Utiliza un objeto al azar de la lista
        int index = rand.nextInt(objectes.size()); // Suponiendo que tienes un rand definido en Personatges
        Objectes objecte = objectes.get(index);
        System.out.println("Bond está utilizando: " + objecte.getDescripcio());

        // Aquí puedes implementar lógica adicional según el objeto utilizado
    }

    public void CogerObjeto(Objectes objecte) {
        objectes.add(objecte); // Agregar el objeto a la lista
        System.out.println("Has agafat un objecte: " + objecte.getDescripcio());
    }

    public void Deixar() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'Deixar'");
    }

    public void Encendre() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'Encendre'");
    }

    public void Apagar() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'Apagar'");
    }

    public void Obrir() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'Obrir'");
    }

    public void Tancar() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'Tancar'");
    }

    public static boolean Despertar() {
        boolean Despertar = true;

        return Despertar;
    }
}