import java.util.Scanner;
import java.util.Random;

public class Nau {
    private Random rand = new Random();
    private int pedro = 0;
    private Scanner scanner;
    private Bond bond; // Cambiamos Personatges a Bond

    public Nau() {
        scanner = new Scanner(System.in);
    }

    public static void main(String[] args) {
        Nau nau = new Nau();
        nau.jugar();
    }

    public void jugar() {
        boolean jugar = true;
        int torn = 0;
        while (jugar) {
            MapaHabitaciones.mostrarPosicioActual();
            System.out.println("Que vols fer?\nq = sortir\n1. Moure\n2. Deixar\n3. Agafar\n4. Encendre\n5. Apagar\n6. Obrir\n7. Usar\n8. Parlar\n9. Tancar\n10. Despertar");
            System.out.println();
            String cosa = scanner.next();
            switch (cosa.toLowerCase()) {
                case "q":
                    jugar = false;
                    System.out.println("Has sortit del joc.");
                    break;
                case "1":
                    pedro = rand.nextInt(3);
                    if (pedro == 0) {
                        iHall.falseMoure();
                    } else{
                        bond.Movimiento();
                    }
                    torn++;
                    // Gustabo.Movimiento(torn); // Comentar o implementar correctamente si se necesita
                    break;
                case "2":
                    bond.Deixar();
                    break;
                case "3":
                // Aquí debes crear un nuevo objeto y pasárselo al método CogerObjeto
                    Objectes nuevoObjeto = new Objectes(); // Asumiendo que creas un nuevo objeto
                    bond.CogerObjeto(nuevoObjeto);
                    break;
                case "4":
                    bond.Encendre();
                    break;
                case "5":
                    bond.Apagar();
                    break;
                case "6":
                    bond.Obrir();
                    break;
                case "7":
                    bond.utilitzarObjecte();
                    break;
                case "8":
                    iHall.llanterna();
                    break;
                case "9":
                    bond.Tancar();
                    break;
                case "10":
                    Bond.Despertar();
                    break;
                default:
                    System.out.println("Acció no reconeguda. Intenta de nou.");
            }
        }
    }
}

/*import java.util.Scanner;
import java.util.Random;

public class Nau {
    private Random rand = new Random();
    int iHall = 0;
    private Scanner scanner;
    private MapaHabitaciones mapa;
    private Personatges personatge;
    public Nau() {
        scanner = new Scanner(System.in);
        mapa = new MapaHabitaciones();
        personatge = new Personatges(mapa); 
    }

    public static void main(String[] args) {
        Nau nau = new Nau();
        nau.jugar();
    }

    public void jugar() {
        mapa.mostrarPosicioActual();
        boolean jugar = true;
        int torn = 0;
        while (jugar) {
            System.out.println("Que vols fer?\nq = sortir\n1. Moure\n2. Deixar\n3. Agafar\n4. Encendre\n5. Apagar\n6. Obrir\n7. Usar\n8. Parlar\n9. Tancar");
            System.out.println();
            String cosa = scanner.next();
            switch (cosa.toLowerCase()) {
                case "q":
                    jugar = false;
                    System.out.println("Has sortit del joc.");
                    break;
                case "1":
                    iHall = rand.nextInt(1);
                    if(iHall == 0){
                        personatge.Movimiento();
                    }else if(iHall == 1){
                        iHall.falseMoure();
                    }
                    torn++;
                    Gustabo.Movimiento(torn);
                    break;
                case "2":
                    Bond.Deixar();
                    break;
                case "3":
                    Bond.Agafar();
                    break;
                case "4":
                    Bond.Encendre();
                    break;
                case "5":
                    Bond.Apagar();
                    break;
                case "6":
                    Bond.Obrir();
                    break;
                case "7":
                    Bond.Usar();
                    break;
                case "8":
                    Bond.Parlar();
                    break;
                case "9":
                    Bond.Tancar();
                    break;
                default:
            }
            
        }
    }
}*/
