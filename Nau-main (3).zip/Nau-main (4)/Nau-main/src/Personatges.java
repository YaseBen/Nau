/*import java.util.ArrayList;
import java.util.Scanner;

public class Personatges {
    private Scanner e;
    private MapaHabitaciones mapa;

    public Personatges(MapaHabitaciones mapa) {
        this.e = new Scanner(System.in);
        this.mapa = mapa;
    }

    public void Movimiento() {
        mapa.mostrarPosicioActual();
        System.out.println("A quina direcció et vols moure? (w = amunt, s = abaix, a = esquerra, d = dreta)");
        String direccio = e.next();

        switch (direccio.toLowerCase()) {
            case "w":
                mapa.moureAmunt();
                break;
            case "s":
                mapa.moureAbaix();
                break;
            case "a":
                mapa.moureEsquerra();
                break;
            case "d":
                mapa.moureDreta();
                break;
            default:
                System.out.println("Direcció no vàlida. Perds un torn mirant les mussaranyes.");
        }
    }
    
    public void Comer() {
        System.out.println("Estàs menjant...");
    }
}
*/