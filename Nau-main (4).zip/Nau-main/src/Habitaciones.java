import java.util.Random;

public class Habitaciones {
    private int nombre;
    private int dreta;
    private int esquerra;
    private int amunt;
    private int abaix;
    private String descripcio;
    boolean eina;
    boolean donuts;
    boolean vestitEspacial;
    Random rand = new Random();

    public Habitaciones(int nombre) {
        this.nombre = nombre;
        this.eina = rand.nextBoolean();
        this.donuts = rand.nextBoolean();
        this.vestitEspacial = rand.nextBoolean();
        configurarHabitacio();
    }

    private void configurarHabitacio() {
        switch (nombre) {
            case 1:
                this.dreta = -1;
                this.esquerra = 7;
                this.amunt = 2;
                this.abaix = -1;
                this.descripcio = "Dormitori";
                break;
            case 2:
                this.dreta = -1;
                this.esquerra = 3;
                this.amunt = -1;
                this.abaix = 1;
                this.descripcio = "Banys";
                break;
            case 3:
                this.dreta = 2;
                this.esquerra = 5;
                this.amunt = 4;
                this.abaix = 9;
                this.descripcio = "Oficines";
                break;
            case 4:
                this.dreta = -1;
                this.esquerra = -1;
                this.amunt = -1;
                this.abaix = 3;
                this.descripcio = "Taller";
                break;
            case 5:
                this.dreta = 3;
                this.esquerra = -1;
                this.amunt = -1;
                this.abaix = 6;
                this.descripcio = "Vestuari";
                break;
            case 6:
                this.dreta = 7;
                this.esquerra = -1;
                this.amunt = 5;
                this.abaix = -1;
                this.descripcio = "Cuina";
                break;
            case 7:
                this.dreta = 1;
                this.esquerra = 6;
                this.amunt = -1;
                this.abaix = 8;
                this.descripcio = "Menjador";
                break;
            case 8:
                this.dreta = -1;
                this.esquerra = -1;
                this.amunt = 7;
                this.abaix = 10;
                this.descripcio = "Sala sortida exterior";
                break;
            case 9:
                this.dreta = -1;
                this.esquerra = -1;
                this.amunt = 3;
                this.abaix = -1;
                this.descripcio = "Comandament";
                break;
            case 10:
                this.dreta = -1;
                this.esquerra = -1;
                this.amunt = 8;
                this.abaix = -1;
                this.descripcio = "Propulsors";
                break;
        }
    }

    public int getNombre() {
        return nombre;
    }

    public int getDreta() {
        return dreta;
    }

    public int getEsquerra() {
        return esquerra;
    }

    public int getAmunt() {
        return amunt;
    }

    public int getAbaix() {
        return abaix;
    }

    public String getDescripcio() {
        return descripcio;
    }
}
