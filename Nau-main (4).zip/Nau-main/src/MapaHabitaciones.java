import java.util.ArrayList;

public class MapaHabitaciones {
    private int posicioActual;
    private ArrayList<Habitaciones> mapa;

    public MapaHabitaciones() {
        mapa = new ArrayList<>(10);

        // Inicialitzem les habitacions
        for (int i = 1; i <= 10; i++) {
            mapa.add(new Habitaciones(i));
        }

        // Inicialitzem la posició actual (habitació 1)
        posicioActual = 0;
    }

    // Moure cap a la dreta
    public void moureDreta() {
        int novaPosicio = mapa.get(posicioActual).getDreta();
        if (novaPosicio != -1) {
            posicioActual = novaPosicio - 1;
            mostrarPosicioActual();
        } else {
            System.out.println("No pots moure't més a la dreta.");
        }
    }

    // Moure cap a l'esquerra
    public void moureEsquerra() {
        int novaPosicio = mapa.get(posicioActual).getEsquerra();
        if (novaPosicio != -1) {
            posicioActual = novaPosicio - 1;
            mostrarPosicioActual();
        } else {
            System.out.println("No pots moure't més a l'esquerra.");
        }
    }

    // Moure cap amunt
    public void moureAmunt() {
        int novaPosicio = mapa.get(posicioActual).getAmunt();
        if (novaPosicio != -1) {
            posicioActual = novaPosicio - 1;
            mostrarPosicioActual();
        } else {
            System.out.println("No pots moure't més amunt.");
        }
    }

    // Moure cap avall
    public void moureAbaix() {
        int novaPosicio = mapa.get(posicioActual).getAbaix();
        if (novaPosicio != -1) {
            posicioActual = novaPosicio - 1;
            mostrarPosicioActual();
        } else {
            System.out.println("No pots moure't més avall.");
        }
    }

    // Obtenir la posició actual
    public void mostrarPosicioActual() {
        System.out.println("Estàs a: " + mapa.get(posicioActual).getDescripcio());
    }
}
