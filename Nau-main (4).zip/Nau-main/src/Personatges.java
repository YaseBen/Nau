public class Personatges {

    public void Movimiento(){

    }

    public void Comer(){

    }

    public void Utilitzar(){

    }

    public void CogerObjeto(){
        
    }

}
