import java.util.Scanner;

public class Nau {
    private Scanner scanner;
    private MapaHabitaciones mapa;

    public Nau() {
        scanner = new Scanner(System.in);
        mapa = new MapaHabitaciones();
    }

    public static void main(String[] args) {
        Nau nau = new Nau();
        nau.jugar();
    }

    public void jugar() {
        boolean jugar = true;
        mapa.mostrarPosicioActual();

        while (jugar) {
            System.out.println(
                    "A quina direcció et vols moure? (w = amunt, s = abaix, a = esquerra, d = dreta, q = sortir)");
            String direccio = scanner.next();

            switch (direccio.toLowerCase()) {
                case "w":
                    mapa.moureAmunt();
                    break;
                case "s":
                    mapa.moureAbaix();
                    break;
                case "a":
                    mapa.moureEsquerra();
                    break;
                case "d":
                    mapa.moureDreta();
                    break;
                case "q":
                    jugar = false;
                    System.out.println("Has sortit del joc.");
                    break;
                default:
                    System.out.println("Direcció no vàlida. Prova de nou.");
            }
        }

        scanner.close();
    }
}
