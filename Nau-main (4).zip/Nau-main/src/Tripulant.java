public class Tripulant extends Personatges{

}
