import java.util.ArrayList;

public class MapaHabitaciones {
    private int posicioActual;
    private ArrayList<Habitaciones> mapa;

    public MapaHabitaciones() {
        mapa = new ArrayList<>(10);

        // Inicialitzem les habitacions
        for (int i = 1; i <= 10; i++) {
            mapa.add(new Habitaciones(i));
        }
        Habitaciones primeraHabitacio = mapa.get(0);
        // Inicialitzem la posició actual (habitació 1)
        posicioActual = 0;
    }

    public void moureDreta() {
        int novaPosicio = mapa.get(posicioActual).getDreta();
        if (novaPosicio != -1) {
            posicioActual = novaPosicio - 1;
            mostrarPosicioActual();
        } else {
            System.out.println("No pots moure't més a la dreta. Perds un torn xocant contra la paret.");
        }
    }

    public void moureEsquerra() {
        int novaPosicio = mapa.get(posicioActual).getEsquerra();
        if (novaPosicio != -1) {
            posicioActual = novaPosicio - 1;
            mostrarPosicioActual();
        } else {
            System.out.println("No pots moure't més a l'esquerra. Perds un torn xocant contra la paret.");
        }
    }

    public void moureAmunt() {
        int novaPosicio = mapa.get(posicioActual).getAmunt();
        if (novaPosicio != -1) {
            posicioActual = novaPosicio - 1;
            mostrarPosicioActual();
        } else {
            System.out.println("No pots moure't més amunt. Perds un torn xocant contra la paret.");
        }
    }

    public void moureAbaix() {
        int novaPosicio = mapa.get(posicioActual).getAbaix();
        if (novaPosicio != -1) {
            posicioActual = novaPosicio - 1;
            mostrarPosicioActual();
        } else {
            System.out.println("No pots moure't més avall. Perds un torn xocant contra la paret.");
        }
    }

    public void mostrarPosicioActual() {
        System.out.println("Estàs a: " + mapa.get(posicioActual).getDescripcio());
    }
}
