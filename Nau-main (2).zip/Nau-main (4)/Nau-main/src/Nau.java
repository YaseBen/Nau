import java.util.Scanner;

public class Nau {
    private Scanner scanner;
    private MapaHabitaciones mapa;
    private Personatges personatge;
    public Nau() {
        scanner = new Scanner(System.in);
        mapa = new MapaHabitaciones();
        personatge = new Personatges(mapa); 
    }

    public static void main(String[] args) {
        Nau nau = new Nau();
        nau.jugar();
    }

    public void jugar() {
        mapa.mostrarPosicioActual();
        boolean jugar = true;
        int torn = 0;
        while (jugar) {
            System.out.println("Que vols fer?\nq = sortir\n1. Moure\n2. Deixar\n3. Agafar\n4. Encendre\n5. Apagar\n6. Obrir\n7. Usar\n8. Parlar\n9. Tancar");
            System.out.println();
            String cosa = scanner.next();
            switch (cosa.toLowerCase()) {
                case "q":
                    jugar = false;
                    System.out.println("Has sortit del joc.");
                    break;
                case "1":
                    personatge.Movimiento();
                    torn++;
                    Gustabo.Movimiento(torn);
                    break;
                case "2":
                    Bond.Deixar();
                    break;
                case "3":
                    Bond.Agafar();
                    break;
                case "4":
                    Bond.Encendre();
                    break;
                case "5":
                    Bond.Apagar();
                    break;
                case "6":
                    Bond.Obrir();
                    break;
                case "7":
                    Bond.Usar();
                    break;
                case "8":
                    Bond.Parlar();
                    break;
                case "9":
                    Bond.Tancar();
                    break;
                default:
            }
            
        }
    }
}
