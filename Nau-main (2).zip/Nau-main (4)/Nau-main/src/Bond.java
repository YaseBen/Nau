public class Bond extends Personatges {
    public Bond(MapaHabitaciones mapa) {
        super(mapa);  
    }
    public void Movimiento() {
        super.Movimiento(); 
    }
    public void Utilitzar() {
        System.out.println("Bond está usando un gadget especial.");
    }
}
