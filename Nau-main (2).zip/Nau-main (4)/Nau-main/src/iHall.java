import java.util.Random;

public class iHall{
Random rand = new Random();

    public void Llanterna(){
        int resposta = rand.nextInt(1);
        if(resposta == 1){
            System.out.println("BoNd, La LlEnTeRnA eStÀ a "+mapa.get(getLlanterna()).getDescripcion()+" CoM sEmPrE");
        }else if(resposta == 0){
            System.out.println();
        }
            
    }
    
}
