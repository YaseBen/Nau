public class Gustabo extends Personatges {
    public Gustabo(MapaHabitaciones mapa){
        super(mapa);
    }

    public static void Movimiento(int torn){
        if (torn%2==2) {
            
        }
    }
}
